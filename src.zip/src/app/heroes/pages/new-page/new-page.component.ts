import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HeroesService } from '../../services/heroes.service';
import { Hero } from '../../interfaces/hero.interfaces';

@Component({
  selector: 'app-new-page',
  standalone: false,
  
  templateUrl: './new-page.component.html',
  styles: ``
})
export class NewPageComponent {
heroForm: FormGroup<any> | undefined;
publishers: any;
saveHero() {
throw new Error('Method not implemented.');
}


}
