import {
  MatDivider,
  MatDividerModule
} from "./chunk-JF5E2CK6.js";
import "./chunk-GZHNZPTC.js";
import "./chunk-AAQCQZKN.js";
import "./chunk-4ZTS33T5.js";
import "./chunk-NLOMWOEW.js";
import "./chunk-SAEO7BCD.js";
import "./chunk-E7R4FTH5.js";
import "./chunk-5TID76VL.js";
export {
  MatDivider,
  MatDividerModule
};
